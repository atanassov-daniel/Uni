% a)
userDefinedList(nil).
userDefinedList(cons(_,XS)) :- userDefinedList(XS).

% b)
asPrologList([], nil).
asPrologList([X|XS], cons(X,YS)) :- asPrologList(XS, YS).

% c)
maximum(0, X, X).
maximum(X, 0, X).
maximum(s(X),s(Y), s(Z)) :- maximum(X,Y,Z).

maximumList([], 0).
maximumList([X|XS], Y) :- maximumList(XS, Z), maximum(X,Z,Y).

% d)
remove([X|XS], X, XS).
remove([X|XS], Y, [X|YS]) :- remove(XS, Y, YS).

% e)
sortList([],[]).
sortList(XS, [Y|YS]) :- maximumList(XS, Y), remove(XS, Y, ZS), sortList(ZS, YS).

% f)
isZermelo([]).
isZermelo([XS|XS]) :- isZermelo(XS).

% g)
numberChange([],0).
numberChange([XS|XS],s(Z)) :- numberChange(XS,Z).

% h)
zermeloPlus([],XS,XS)           :- isZermelo(XS).
zermeloPlus([XS|XS],YS,[ZS|ZS]) :- isZermelo([XS|XS]), zermeloPlus(XS,YS,ZS).

% i)
removeConsecutive([],[]).
removeConsecutive([X],[X]).
removeConsecutive([X,X|XS], [X|YS])   :- removeConsecutive([X|XS], [X|YS]).
removeConsecutive([X,Y|XS], [X,Y|YS]) :- removeConsecutive([Y|XS], [Y|YS]).

flatten([], []).
flatten([[]|XS], YS)            :- flatten(XS, YS).
flatten([[X|XS] | XSS], [X|YS]) :- flatten([XS|XSS], YS).

flattenConsecutive(XS,YS) :- flatten(XS,ZS), removeConsecutive(ZS, YS).

% j)
% node(X,Children)
% Das Funktionssymbol node dient zur Repraesentation eines Knotens,
% wobei X den gespeicherten Wert und Children die Liste der Kindknoten
% darstellt.

% k)
%X = node([1,2,3],[node([],[node([3],[]),node([3,7],[])]),node([],[]),
% node([7,15],[node([7,7],[])])])
append([],YS,YS).
append([X|XS],YS,[X|ZS]) :- append(XS,YS,ZS).

treeToList(node(X,[]), [X]).
treeToList(node(X,[Child|Children]), [X|XS]) :-
    treeToList(Child,YS), treeToList(node(X,Children), [X|ZS]), append(YS,ZS,XS).

flattenConsecutiveTree(X,Y) :- treeToList(X,Z), flattenConsecutive(Z,Y).
