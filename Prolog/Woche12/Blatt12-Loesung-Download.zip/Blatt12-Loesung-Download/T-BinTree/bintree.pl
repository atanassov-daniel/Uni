% Teilaufgabe a)
increment(leaf(X),leaf(s(X))).
increment(node(L, N, R), node(IncL, s(N), IncR)) :- increment(L, IncL),
                                                    increment(R, IncR).

% Teilaufgabe b)
append([], XS, XS).
append([X|XS], YS, [X|Res]) :- append(XS, YS, Res).

% Teilaufgabe c)
inorder(leaf(X),[X]).
inorder(node(L, N, R), Res) :- 
	inorder(L,ResL),
	inorder(R,ResR), 
	append(ResL, [N|ResR], Res).