% Teilaufgabe a)
formel(true).
formel(false).
formel(and(X,Y))  :- formel(X), formel(Y).
formel(or(X,Y))   :- formel(X), formel(Y).

% Teilaufgabe b)
istWahr(true).
istWahr(and(X,Y)) :- istWahr(X), istWahr(Y).
istWahr(or(X,_))  :- istWahr(X).
istWahr(or(_,Y)) :- istWahr(Y).

% alternativ Loesung fuer or:
istWahr(or(X,Y))  :- istWahr(X); istWahr(Y).

% Teilaufgabe c)
benutzt(and(X,Y),X) :- formel(X), formel(Y).
benutzt(and(Y,X),X) :- formel(X), formel(Y).
benutzt(or(X,Y),X) :- formel(X), formel(Y).
benutzt(or(Y,X),X) :- formel(X), formel(Y).

% Teilaufgabe d)
beinhaltet(X,Y)  :- benutzt(X,Y).
beinhaltet(X,Y)  :- benutzt(X,Z), beinhaltet(Z,Y).

% Teilaufgabe e)
% ?- formel(and(X,Y)).

% Teilaufgabe f)
% ?- benutzt(and(true,false),X).
% X = true;
% X = false.
%
% ?- formel(and(true,X)).
% X = true;
% X = false;
% X = and(true,true);
% X = and(true,false);
% X = and(true,and(true,true));
%
% ?- istWahr(and(true,X)).
% X = true;
% X = and(true,true);
% X = and(true,and(true,true));
% X = and(true,and(true,and(true,true)));
% X = and(true,and(true,and(true,and(true,true))));