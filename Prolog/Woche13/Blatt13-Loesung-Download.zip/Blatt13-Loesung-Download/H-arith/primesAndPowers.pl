% notdivisor(N,X) ist wahr gdw. N nicht durch X teilbar ist.
notdivisor(N,X) :- Y is N mod X, Y > 0.

%nodivisors(N,X) ist wahr gdw. N keine Teiler zwischen X und 2 hat.
nodivisors(_,1).
nodivisors(N,X) :- notdivisor(N,X), Y is X - 1, nodivisors(N, Y).

prime(N):- N > 1, X is N-1, nodivisors(N,X).

only_primes([]).
only_primes([X|XS]) :- prime(X), only_primes(XS).

powers(X, 1, [X]) :- X > 0.
powers(X, N, [P1,P2|R]) :- X > 0,
                        N > 1, 
                        N1 is N - 1,
                        powers(X, N1, [P2|R]), 
                        P1 is P2 * X.