pow :: Int -> Int -> Int
pow _ 0 = 1
pow a b = a * pow a (b-1)

isDiv :: Int -> Int -> Bool
isDiv 0 _ = True 
isDiv _ 0 = False
isDiv a b = modHelp (absHelp a) (absHelp b) == 0
  where
    modHelp a b | a < b = a
                | otherwise = modHelp (a-b) b
    absHelp c |c  > 0 = c
              |c <= 0 = -c
              
sumUp :: [Int] -> Int
sumUp [] = 0
sumUp (x:xs) = x + sumUp xs

multLists :: [Int]->[Int]->[Int]
multLists _ [] = []
multLists [] _ = []
multLists (x:xs) (y:ys) = x*y:multLists xs ys

isEven :: Int -> Bool
isEven 0 = True
isEven n | n>0        = isOdd (n-1)
         | otherwise  = isOdd (n+1)

isOdd :: Int -> Bool
isOdd n = not (isEven n)
           
binRep :: Int -> (Int,[Int])
binRep 0 = (0,[0])
binRep n |n > 0 = (1, binRepHelp n)
         |n < 0 = ((-1), binRepHelp (-n))
  where
    binRepHelp 0 = []
    binRepHelp n = binRepHelp (div n 2) ++ [rem n 2]
