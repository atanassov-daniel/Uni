t1 :: MultTree Int
t1 = IndexNode 3 42 [IndexNode 3 15 [DataLeaf 3, DataLeaf 11, DataLeaf 12]
                    , IndexNode 19 42 [DataLeaf 42, DataLeaf 23]]

data MultTree a = IndexNode a a [MultTree a] | DataLeaf a deriving Show

verzweigungsgrad :: MultTree a -> Int
verzweigungsgrad (DataLeaf _) = 0
verzweigungsgrad node = verzweigungsgrad' 0 node
  where
    verzweigungsgrad' self (IndexNode _ _ []) = self
    verzweigungsgrad' self (IndexNode x y (t:ts)) =
      max (verzweigungsgrad t) (verzweigungsgrad' (self+1) (IndexNode x y ts))

datenListe :: MultTree a -> [a]
datenListe (DataLeaf x) = [x]
datenListe (IndexNode x y (t:ts)) = datenListe t ++ datenListe (IndexNode x y ts)
datenListe (IndexNode _ _ []) = []

contains :: Int -> MultTree Int -> Bool
contains n (DataLeaf x) = x == n
contains n (IndexNode x y (t:ts)) | n < x || n > y = False
                                  | otherwise = contains n t
                                                || contains n (IndexNode x y ts)
contains _ _ = False

