data Tree a = Node a [Tree a]
            | Nil deriving Show

testTree :: Tree Int
testTree = Node 2
  [ Nil
  , Node 3 [ Node 9 []
           , Node 5 []
           , Node 10 [ Node 0 [] ]]
  , Node 1 [ Node 5 []
            , Nil ]]

-- a)
mapTree :: (a -> b) -> Tree a -> Tree b
mapTree f Nil = Nil
mapTree f (Node a ts) = Node (f a) (map (mapTree f) ts)


-- b)
mapTreeWithPath :: ([a] -> a -> b) -> Tree a -> Tree b
mapTreeWithPath f = go []
  where
    go _    Nil = Nil
    go path (Node a ts) = Node (f path a) (map (go (a:path)) ts)


-- c)
filterTree  :: (a -> Bool) -> Tree a -> Tree a
filterTree  _ Nil = Nil
filterTree  p (Node a ts)
  | p a = Node a (map (filterTree p) ts)
  | otherwise = Nil


-- d)
foldTree :: (a -> [b] -> b) -> b -> Tree a -> b
foldTree f c Nil = c
foldTree f c (Node a ts) = f a (map (foldTree f c) ts)


-- e)
toOnes :: Tree a -> Tree Int
toOnes = mapTree (\_ -> 1)


-- f)
numNodes :: Tree a -> Int
numNodes = foldTree (\v is -> v + sum is) 0 . toOnes
