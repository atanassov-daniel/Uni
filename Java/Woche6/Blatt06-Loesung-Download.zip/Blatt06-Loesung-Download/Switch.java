/**
 * Ein Objekt der Klasse Switch repraesentiert eine Weiche in einer Murmelbahn.
 * Jeder Switch hat genau zwei Nachfolger.
 * Eingehende Murmeln werden abwechselnd zuerst an den linken und dann an den rechten,
 * dann wieder an den linken Nachfolger usw. weitergeleitet.
 */
 public class Switch {
    
    private Switch left;
    private Switch right;
    private boolean nextLeft = true;
    private boolean seen = false;
    
    /**
     * Konstruktor fuer einen neuen Switch, der genau zwei Nachfolger hat.
     * @param succ1 der linke Nachfolger
     * @param succ2 der rechte Nachfolger
     */
    public Switch(Switch succ1, Switch succ2) {
        this.left = succ1;
        this.right = succ2;
    }
    
    /**
     * Konstruktor fuer einen neuen Switch, der sich verhaelt,
     * als haette er genau einen Nachfolger.
     * @param next der Nachfolger, an den immer weitergeleitet wird
     */
    public Switch(Switch next) {
        this.left = next;
        this.right = next;
    }
    
    /**
     * Konstruktor fuer einen neuen Switch, der sich verhaelt,
     * als haette er genau drei Nachfolger.
     * @param s0 der Nachfolger, an den als erstes weitergeleitet wird
     * @param s1 der Nachfolger, an den als zweites weitergeleitet wird
     * @param s2 der Nachfolger, an den als drittes weitergeleitet wird
     */
    public Switch(Switch s0, Switch s1, Switch s2) {
        this.left = new Switch(s0,s2);
        this.right = new Switch(s1,this);
    }
    
    /**
     * Leitet die eingehende Murmel an den aktiven Nachfolger weiter, tauscht Nachfolger.
     * @return den Switch, an den die Kugel weitergeleitet wird
     */
    public Switch next() {
        if (nextLeft) {
            this.nextLeft = !this.nextLeft;
            return left;
        } else {
            this.nextLeft = !this.nextLeft;
            return right;
        }
    }
    
    /**
     * Leitet die eingehende Murmel einmal durch die ganze Murmelbahn.
     * @return den letzten Switch, bevor die Bahn verlassen wird
     */
    public Switch findLast() {
        Switch next = this.next();
        if (next == null) {
            return this;
        } else {
            return next.findLast();
        }
    }
    
    /**
     * Erstellt ein Array mit den Nachfolgern des Switches, die nicht null sind.
     * @return das erstellte Array
     */
    public Switch[] directSuccessors() {
        if (left == null && right == null) {
            return new Switch[] {};
        } if (left != null && right == null) {
            return new Switch[] {left};
        } if (left == null && right != null) {
            return new Switch[] {right};
        } else {
            return new Switch[] {left,right};
        }
    }
    
    /**
     * Traversiert die Datenstruktur und zaehlt alle verschiedenen erreichbaren Switches.
     * @return die Anzahl an verschiedenen erreichbaren Switches
     */
    public int countSwitches() {
        //Wir gehen davon aus, dass bei allen erreichbaren Switches !seen gilt. Damit das
        //  auch nach dem Aufruf dieser Methode wieder der Fall ist, rufen wir
        //  countSwitches zwei Mal auf, zuerst mit seenValue true, dann mit false
        countSwitches(true);
        return countSwitches(false);
    }
    
    private int countSwitches(boolean seenValue) {
        if (seen == seenValue) {
            return 0;
        } else {
            seen = seenValue;
            int res = 1;
            for (Switch s : directSuccessors()) {
                res += s.countSwitches(seenValue);
            }
            return res;
        }
    }
}