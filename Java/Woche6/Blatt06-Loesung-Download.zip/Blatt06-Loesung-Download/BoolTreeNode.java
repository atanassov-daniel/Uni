/**
 * Ein Objekt der Klasse BoolTreeNode repraesentiert einen booleschen Binaerbaum.
 * Dieser Baum steht fuer eine boolesche Formel ueber Variablen, true und false.
 */
public class BoolTreeNode {
    private String variable;
    private BoolTreeNode child1;
    private BoolTreeNode child2;

    /**
     * Konstruktor fuer einen neuen booleschen Binaerbaum,
     * der eine Variable repraesentiert.
     * @param variableInput die zu repraesentierende Variable
     */
    private BoolTreeNode(String variableInput) {
        variable = variableInput;
        child1 = null;
        child2 = null;
    }

    /**
     * Konstruktor fuer einen neuen booleschen Binaerbaum,
     * der die Negation der Repraesentation des uebergebenen Baums repraesentiert.
     * @param negated der zu negierende Binaerbaum
     */
    private BoolTreeNode(BoolTreeNode negated) {
        variable = "";
        child1 = negated;
        child2 = null;
    }

    /**
     * Konstruktor fuer einen neuen booleschen Binaerbaum, der die
     * Konjunktion der Repraesentationen der uebergebenen Baeume repraesentiert.
     * @param conjunct1 der erste zu konjugierende Binaerbaum
     * @param conjunct2 der zweite zu konjugierende Binaerbaum
     */
    private BoolTreeNode(BoolTreeNode conjunct1, BoolTreeNode conjunct2) {
        variable = "";
        child1 = conjunct1;
        child2 = conjunct2;
    }

    /**
     * Erzeugt einen neuen booleschen Binaerbaum, der true repraesentiert.
     * @return den neuen booleschen Binaerbaum, der true repraesentiert
     */
    public static BoolTreeNode boolTreeTrueNode() {
        BoolTreeNode res = new BoolTreeNode("true");
        return res;
    }

    /**
     * Erzeugt einen neuen booleschen Binaerbaum, der false repraesentiert.
     * @return den neuen booleschen Binaerbaum, der false repraesentiert
     */
    public static BoolTreeNode boolTreeFalseNode() {
        BoolTreeNode res = new BoolTreeNode("false");
        return res;
    }

    /**
     * Erzeugt einen neuen booleschen Binaerbaum, der eine Variable repraesentiert.
     * @param variableInput die zu repraesentierende Variable
     * @return den neuen booleschen Binaerbaum, der die Variable repraesentiert
     */
    public static BoolTreeNode boolTreeVariableNode(String variableInput) {
        if (variableInput.equals("true") || variableInput.equals("false")) {
            Utils.error("Variable must not be namend \"true\" or \"false\"");
            return null;
        } else if (variableInput.equals("")) {
            Utils.error("Variable must not have empty string as name");
            return null;            
        } else {
            BoolTreeNode res = new BoolTreeNode(variableInput);
            return res;
        }
    }

    /**
     * Erzeugt einen neuen booleschen Binaerbaum, der eine Negation repraesentiert.
     * @param negated der Binaerbaum der zu negierenden Formel
     * @return den neuen booleschen Binaerbaum, der die Negation repraesentiert
     */
    public static BoolTreeNode boolTreeNotNode(BoolTreeNode negated) {
        if (negated == null) {
            Utils.error("Negation-child is null, new node cannot be created");
            return null;            
        }
        BoolTreeNode notnode = new BoolTreeNode(negated);
        return notnode;
    }

    /**
     * Erzeugt einen neuen booleschen Binaerbaum, der eine Konjunktion repraesentiert.
     * @param conjunct1 der Binaerbaum der ersten zu konjugierenden Formel
     * @param conjunct2 der Binaerbaum der zweiten zu konjugierenden Formel
     * @return den neuen booleschen Binaerbaum, der die Konjunktion repraesentiert
     */
    public static BoolTreeNode boolTreeAndNode(BoolTreeNode conjunct1, BoolTreeNode conjunct2) {
        if (conjunct1 == null || conjunct2 == null) {
            if (conjunct1 != null || conjunct2 != null) {
                Utils.error("One of the conjunction-children is null, new node cannot be created");
                return null;
            } else {
                Utils.error("Both conjunction-children are null, new node cannot be created");
                return null;
            }
        }
        BoolTreeNode andnode = new BoolTreeNode(conjunct1,conjunct2);
        return andnode;
    }

    /**
     * Ermittelt die Tiefe des booleschen Binaerbaums.
     * @return die Tiefe des booleschen Binaerbaums
     */
    public int depth() {
        if (child1 != null) {
            int depth1 = child1.depth();
            if (child2 != null) {
                int depth2 = child2.depth();
                return Utils.max(depth1,depth2) + 1;
            } else {
                return depth1 + 1;
            }
        } else {
            return 0;
        }
    }

    /**
     * Ermittelt, ob der boolesche Binaerbaum ein Blatt ist, also keine Kinder hat.
     * @return true, wenn der Baum ein Blatt ist, sonst false
     */
    public boolean isLeaf() {
        return (child1 == null && child2 == null);
    }

    /**
     * Ermittelt, ob der boolesche Binaerbaum ein Blatt ist, das true repraesentiert.
     * @return true, wenn der Baum ein Blatt ist und true repraesentiert, sonst false
     */
    public boolean isTrueLeaf() {
        return (isLeaf() && variable.equals("true"));
    }

    /**
     * Ermittelt, ob der boolesche Binaerbaum ein Blatt ist, das false repraesentiert.
     * @return true, wenn der Baum ein Blatt ist und false repraesentiert, sonst false
     */
    public boolean isFalseLeaf() {
        return (isLeaf() && variable.equals("false"));
    }

    /**
     * Ermittelt, ob der boolesche Binaerbaum eine Negation repraesentiert.
     * @return true, wenn der Baum eine Negation repraesentiert, sonst false
     */
    public boolean isNegation() {
        return (child1 != null && child2 == null);
    }

    /**
     * Ermittelt, ob der boolesche Binaerbaum eine Konjunktion repraesentiert.
     * @return true, wenn der Baum eine Konjunktion repraesentiert, sonst false
     */
    public boolean isConjunction() {
        return (child1 != null && child2 != null);
    }

    /**
     * Ermittelt den Wahrheitswert der durch den booleschen Binaerbaum repraesentierten
     * Formel bei einer gegebenen Variablenbelegung.
     * @param trueVars genau die Variablen, die zu true evaluiert werden
     * @return true, wenn die repraesentierte Formel zu true evaluiert wird, sonst false
     */
    public boolean evaluate(String... trueVars) {
        if (isLeaf()) {
            return Utils.evaluateVariable(variable,trueVars);
        } else if (isNegation()) {
            return !(child1.evaluate(trueVars));
        } else if (isConjunction()) {
            return child1.evaluate(trueVars) && child2.evaluate(trueVars);
        } else {
            Utils.error("Should never occur");
            return false;
        }
    }

}
