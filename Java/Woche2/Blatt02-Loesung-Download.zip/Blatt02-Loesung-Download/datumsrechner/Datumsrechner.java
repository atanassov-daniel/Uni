
public class Datumsrechner {
  public static void main(String args[]) {
    // Wir zaehlen von 0..30
    int tag =
      SimpleIO.getInt("Bitte geben Sie die Tageskomponente des Startdatums ein.") - 1;
    // Wir zaehlen von 0..11
    int monat =
      SimpleIO.getInt("Bitte geben Sie die Monatskomponente des Startdatums ein.") - 1;
    int jahr =
      SimpleIO.getInt("Bitte geben Sie die Jahreskomponente des Startdatums ein.");

    int anzahlTage = SimpleIO.getInt("Bitte geben Sie die Anzahl an Tagen ein.");

    for (int i = 0; i<anzahlTage; ++i) {
      switch(monat) {
        // Monat mit 28 Tagen (Februar)
        case 1 -> {
          if (tag == 27)
            ++monat;
          tag = (tag + 1) % 28;
        }

        // Monate mit 30 Tagen
        case 3,5,8,10 -> {
          if (tag == 29)
            ++monat;
          tag = (tag + 1) % 30;
        }

        // Alle anderen Monate haben 31 Tage
        default -> {
          if (tag == 30) {
            if (monat == 11)
              ++jahr;
            monat = (monat + 1) % 12;
          }
          tag = (tag+1) % 31;
        }
      }
    }
    ++tag; ++monat;

    SimpleIO.output("Das Datum "+tag+"."+monat+"."+jahr+" befindet sich "
                    +anzahlTage+" Tage nach dem Startdatum.");
  }
}
