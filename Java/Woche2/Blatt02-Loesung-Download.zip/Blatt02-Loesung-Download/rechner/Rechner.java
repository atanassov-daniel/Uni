/**
 * Programm, welches einen simplen Taschenrechner darstellt.
 */
public class Rechner {
  public static void main(String[] args) {
    // Einlesen der initialen Zahl.
    int currentResult = SimpleIO.getInt("Bitte geben Sie eine Zahl ein:");

    // Einlesen der initialen Operation.
    String operation = SimpleIO.getString(
      "Bitte geben Sie eine Rechenoperation (ADD, SUB, MUL, DIV) oder STOP ein:");

    while(!operation.equals("STOP")) {
      int newNumber = SimpleIO.getInt("Bitte geben Sie eine Zahl ein:");
      switch(operation) {
        case "ADD" -> currentResult += newNumber;
        case "SUB" -> currentResult -= newNumber;
        case "MUL" -> currentResult *= newNumber;
        case "DIV" -> currentResult /= newNumber;
        default -> {SimpleIO.output("Fehlerhafte Eingabe!");
                    return;}
      }
      SimpleIO.output("Aktuelles Ergebnis: " + currentResult);
      operation = SimpleIO.getString(
        "Bitte geben Sie eine Rechenoperation (ADD, SUB, MUL, DIV) oder STOP ein:");
    }
    SimpleIO.output("Endergebnis: " + currentResult);
  }
}
