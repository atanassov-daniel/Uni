
public class NegativeTest extends FunctionalTest 
{
	
	public NegativeTest() {
		super("Negative Test");
	}

	@Override
	public TestResult runTest(Program p) {
		int x=-1;
		int y=-5;
		try {
			int r=p.calculate(x, y);
			return new TestResult(true,
				"No error when multiplying negative numbers");
		} catch (NegativeNumbersException e) {
			return new TestResult(false,
				"Correct error when multiplying negative numbers");
		}
	}

}
