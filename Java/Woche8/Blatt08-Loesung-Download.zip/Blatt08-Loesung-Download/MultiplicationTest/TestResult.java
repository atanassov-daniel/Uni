public record TestResult(boolean error, String message) 
{
    
}
