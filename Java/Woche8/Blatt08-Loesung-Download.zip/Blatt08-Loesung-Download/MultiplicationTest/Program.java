
public interface Program extends Identifiable 
{
	public int calculate(int x, int y) throws NegativeNumbersException;
	
}
