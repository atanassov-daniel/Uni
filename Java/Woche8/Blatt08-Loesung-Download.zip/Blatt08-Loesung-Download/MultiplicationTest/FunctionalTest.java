
public abstract non-sealed class FunctionalTest extends Test 
{
	protected FunctionalTest(String identifier) {
		super(identifier);
	}
}
