public class NegativeNumbersException extends Exception 
{

	private final boolean isX;
	private final int value;
    
    public NegativeNumbersException(boolean isX, int value) {
        this.isX = isX;
        this.value = value;
    }
    
    public String toString() {
    	if (isX) {
            return "Der x-Wert " + value + " ist negativ!";
    	} else {
            return "Der y-Wert " + value + " ist negativ!";
    	}
    }
    
}
