
public class PositiveNegativeTest extends FunctionalTest 
{
	
	public PositiveNegativeTest() {
		super("PositiveNegative Test");
	}

	@Override
	public TestResult runTest(Program p) {
		int x=-2;
		int y=5;
		try {
			int r = p.calculate(x, y);
			return new TestResult(true,
				"No error when multiplying a positive and a negative number");
		} catch (NegativeNumbersException e) {
			
		}
		x=5;
		y=-2;
		try {
			int r = p.calculate(x, y);
			return new TestResult(true,
				"No error when multiplying a positive and a negative number");
		} catch (NegativeNumbersException e) {
			
		}
		return new TestResult(false,
			"Correct error when multiplying a positive and a negative number");
	}

}
