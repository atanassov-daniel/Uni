
public interface Identifiable 
{
	public String getName();
}
