public final class Strecke extends Strahl {

    public Strecke(Punkt p1, Punkt p2) throws SinglePointException {
        super(p1,p2);
    }
    
    public Strahl verlaengern(boolean swap) throws SinglePointException {
        if (swap) {
            return new Strahl(getp1(),getp2());
        } else {
            return new Strahl(getp2(),getp1());
        }
    }
    
    public boolean startsFromp1() {
        return true;
    }
    
    public boolean startsFromp2() {
        return true;
    }
    
    public boolean enthaelt(Punkt p0) {
        return zwischenp1p2(p0);
    }
    
    public String toString() {
        return "Strecke zwischen " + this.getp1() + " und " + this.getp2();
    }

}
