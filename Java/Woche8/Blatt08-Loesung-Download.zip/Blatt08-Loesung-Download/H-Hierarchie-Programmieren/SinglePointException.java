public class SinglePointException extends Exception {

    private final Punkt p;
    
    public SinglePointException(Punkt p) {
        this.p = p;
    }
    
    public String toString() {
        return "Doppelte Benutzung des Punktes " + p;
    }

}
