public sealed class Strahl extends Gerade permits Strecke{
    
    private final boolean startFromp1;
    
    public Strahl(Punkt p1, Punkt p2) throws SinglePointException {
        super(p1,p2);
        startFromp1 = (this.getp1() == p1); //check whether a swap has happened
    }

    public Gerade verlaengern() throws SinglePointException {
        return new Gerade(getp1(),getp2());
    }
    
    public boolean startsFromp1() {
        return startFromp1;
    }
    
    public boolean startsFromp2() {
        return !startFromp1;
    }
    
    public boolean enthaelt(Punkt p0) {
        if (zwischenp1p2(p0)) {
            return true; //p0 liegt zwischen p1 und p2
        }
        if (startsFromp1() && hinterp2(p0)) {
            return true; //p0 liegt "rechts von" p2
        }
        if (startsFromp2() && vorp1(p0)) {
            return true; //p0 liegt "links von" p1
        }
        return false;
    }
    
    public String toString() {
        if (startFromp1) {
            return "Strahl von " + this.getp1() + " durch " + this.getp2();
        } else {
            return "Strahl von " + this.getp2() + " durch " + this.getp1();
        }
    }

    public boolean equals(Object obj) {
        if (!super.equals(obj)) {
            return false;
        } else {
            Strahl s = (Strahl)obj;
            return (this.startsFromp1() == s.startsFromp1());
        }
    }

}
