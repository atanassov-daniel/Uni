import java.math.*;

public class Punkt {

    private final BigDecimal x, y;
    
    public Punkt(double x, double y) {
        this.x = new BigDecimal(x);
        this.y = new BigDecimal(y);
    }

    public Punkt(BigDecimal x, BigDecimal y) {
        this.x = x;
        this.y = y;
    }
    
    public BigDecimal getX() {
        return x;
    }
    
    public BigDecimal getY() {
        return y;
    }
    
    public BigDecimal abstand(Punkt other) {
        BigDecimal xDistance = this.getX().subtract(other.getX());
        BigDecimal yDistance = this.getY().subtract(other.getY());
        return BigDecimalUtility.sqrt(xDistance.pow(2).add(yDistance.pow(2)));
    }
    
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        } else if (!(obj instanceof Punkt)) {
            return false;
        }
        Punkt p = (Punkt)obj;
        if (!BigDecimalUtility.equalValues(p.getX(),this.getX())) {
            return false;
        } else if (!BigDecimalUtility.equalValues(p.getY(),this.getY())) {
            return false;
        } else {
            return true;
        }
    }
    
    public String toString() {
        return "(" + x + "," + y + ")";
    }
}
