import java.math.*;

public sealed class Gerade permits Strahl {

    private final Punkt p1, p2;
    
    public Gerade(Punkt p1, Punkt p2) throws SinglePointException{
        if (p1.equals(p2)) {
            throw new SinglePointException(p1);
        } else if (p1.getX().compareTo(p2.getX()) == 1) {
            this.p1 = p2;
            this.p2 = p1;
        } else if ((p1.getX().compareTo(p2.getX()) == 0) && (p1.getY().compareTo(p2.getY()) == 1)) {
            this.p1 = p2;
            this.p2 = p1;
        } else {
            this.p1 = p1;
            this.p2 = p2;
        }
    }
    
    public Punkt getp1() {
        return p1;
    }
    
    public Punkt getp2() {
        return p2;
    }

    protected boolean vorp1(Punkt p0) {
    	if (zwischenp1p2(p0)) {
    		return false;
    	}
    	
        BigDecimal abstand12 = p1.abstand(p2);
        BigDecimal abstand10 = p1.abstand(p0);
        BigDecimal abstand20 = p2.abstand(p0);

        return (BigDecimalUtility.equalValues(abstand20.subtract(abstand10),abstand12));
    }

    protected boolean hinterp2(Punkt p0) {
    	if (zwischenp1p2(p0)) {
    		return false;
    	}
    	
        BigDecimal abstand12 = p1.abstand(p2);
        BigDecimal abstand10 = p1.abstand(p0);
        BigDecimal abstand20 = p2.abstand(p0);

        return (BigDecimalUtility.equalValues(abstand10.subtract(abstand20),abstand12));
    }

    protected boolean zwischenp1p2(Punkt p0) {
        BigDecimal abstand12 = p1.abstand(p2);
        BigDecimal abstand10 = p1.abstand(p0);
        BigDecimal abstand20 = p2.abstand(p0);

        return (BigDecimalUtility.equalValues(abstand10.add(abstand20),abstand12));
    }
    
    public boolean enthaelt(Punkt p0) {
        if (zwischenp1p2(p0)) {
            return true; //p0 liegt zwischen p1 und p2
        }
        if (hinterp2(p0)) {
            return true; //p0 liegt "hinter" p2
        }
        if (vorp1(p0)) {
            return true; //p0 liegt "vor" p1
        }
        return false;
    }
    
    public String toString() {
        return "Gerade durch " + p1 + " und " + p2;
    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        } else if (this.getClass() != obj.getClass()) {
            return false;
        } else {
            Gerade g = (Gerade)obj;
            return (g.enthaelt(this.getp1()) && g.enthaelt(this.getp2()) &&
                    this.enthaelt(g.getp1()) && this.enthaelt(g.getp2()));
        }
    }

}
