import java.util.Stack;
/* Programm, welches einen einfachen Stack implementiert */
public class JavaStack {
  public static void main(String[] args) {
    Stack<String> stack = new Stack<String>();

    String operation = "";
    while (!operation.equals("STOP")) {
      operation = SimpleIO.getString("Bitte geben Sie eine Operation (PUSH, POP, CLEAR, PRINT, STOP) ein:");

      switch (operation) {
        case "PUSH" -> {
          String newElement = SimpleIO.getString("Geben Sie ein zu speicherndes Element ein:");
          stack.push(newElement);
        }
        case "POP" -> {
          if (stack.size() > 0) stack.pop();
        }
        case "CLEAR" -> stack.clear();
        case "PRINT" -> {
          String result = "Stack: " + stack.toString();
          if (stack.size() == 0) result = "Stack ist leer";

          SimpleIO.output(result);
        }
        case "STOP" -> {
          String result = "Stack: " + stack.toString();
          if (stack.size() == 0) result = "Stack ist leer";

          SimpleIO.output(result);
          return;
        }
//Falsche Eingaben->Fehlermeldung, erneut Operation eingeben
        default -> {
          SimpleIO.output("Invalide Operation! Versuchen Sie es bitte erneut!");
          continue;
        }
      }
    }
  }
}