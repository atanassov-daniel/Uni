import java.util.Stack;

/**
 * Programm, welches einen einfachen Stack implementiert
 */
public class JavaStack {
  public static void main(String[] args) {
    Stack<String> stack = new Stack<String>();
    String operation;
    do {
      operation = SimpleIO.getString(
        "Bitte geben Sie eine Operation (PUSH,POP,CLEAR,PRINT,STOP) ein:");
      switch(operation) {
        case "PUSH" -> {
          String new_element =
            SimpleIO.getString("Geben Sie ein zu speicherndes Element ein:");
          stack.push(new_element);
        }
        case "POP" -> stack.pop();
        case "CLEAR" -> stack.clear();
        case "PRINT", "STOP" -> SimpleIO.output("Stack: " + stack.toString());
        default -> SimpleIO.output("Fehlerhafte Eingabe!");
      }
    } while(!operation.equals("STOP"));
  }
}
