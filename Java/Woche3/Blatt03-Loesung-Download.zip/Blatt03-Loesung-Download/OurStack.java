/**
 * Programm, welches einen einfachen Stack implementiert
 */
public class OurStack {
  public static void main(String[] args) {
    int size;
    do
      size = SimpleIO.getInt(
        "Bitte geben Sie die initiale (nicht negative) Groesse ein:");
    while(size <  0);

    String[] stack = new String[size];
    int currentSize = 0;

    String operation;

    do {
      operation = SimpleIO.getString(
        "Bitte geben Sie eine Operation (PUSH,POP,CLEAR,SETSIZE,PRINT,STOP) ein:");
      switch(operation) {
        case "PUSH" -> {
          if (currentSize < stack.length) {
            stack[currentSize] =
              SimpleIO.getString("Geben Sie ein zu speicherndes Element ein:");
            currentSize++;
          } else {
            SimpleIO.output("Stack ist voll.");
          }
        }
        case "POP" -> currentSize = Math.max(0, currentSize - 1);
        case "CLEAR" -> currentSize = 0;
        case "SETSIZE" -> {
          do
            size = SimpleIO.getInt(
              "Bitte geben Sie die (nicht negative) Groesse ein:");
          while(size <  0);
          String[] new_stack = new String[size];
          for(int i = 0; i < Math.min(currentSize, size); i++)
            new_stack[i] = stack[i];
          stack = new_stack;
        }
        case "PRINT", "STOP" -> {
          if(currentSize > 0) {
            String output = "Stack: " + stack[0];
            for(int i = 1; i < currentSize; i++)
              output = output + "," + stack[i];
            SimpleIO.output(output);
          } else {
            SimpleIO.output("Stack ist leer.");
          }
        }
        default -> SimpleIO.output("Fehlerhafte Eingabe!");
      }
    } while(!operation.equals("STOP"));
  }
}
