public class Rechnung {
  
  public static void main (String [] arguments) {
      
      int x, y;
      x = 10;
      y = -1 + 23 * 33 + 3 * 7 * (5 + 6);
      System.out.print ("Das Resultat ist ");
      System.out.println (x + y);
  }
  
        

}


