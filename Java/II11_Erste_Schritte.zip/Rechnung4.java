public class Rechnung4 {
  
  public static void main (String [] arguments) {

      int y = -1 + 23 * 33 + 3 * 7 * (5 + 6);     
     
      int x = SimpleIO.getInt("Gib eine Zahl ein");

     
      //System.out.println ("Das Resultat ist " + (x + y));
      
      SimpleIO.output("Das Resultat ist " + (x + y));
  }

}



