/**
 * Objekte dieser Klasse repraesentieren eine beschriftete Werkzeugkiste.
 *
 * In den Faechern koennen je ein einfaches Werkzeug, eine grosse Menge
 * Materialien oder, in drei nebeneinander liegenden Faechern,
 * ein Elektrowerkzeug untergebracht werden.
 */
public record ToolboxRecord(Tool[] tools, int max_capacity, String name) {
  /**
   * Anzahl Faecher, die ein Elektrowerkzeug belegt.
   */
  public static final int PowerToolSize = 3;

  /**
   * Lese das Werkzeug im i-ten Fach.
   * @param i Nummer des Fachs
   * @return Das Werkzeug im i-ten Fach
   */
  public Tool getTool(int i) {
    if(0 <= i && i < this.tools.length) {
      return this.tools[i];
    } else {
      return null;
    }
  }

  /**
   * Lese Anzahl freier Faecher
   * @return Anzahl freier Faecher
   */
  public int getCapacity() {
    int capacity = max_capacity;
    for(int i = 0; i < tools.length; i++) {
      if(tools[i] != null) {
        capacity--;
      }
    }
    return capacity;
  }

  /**
   * Finde den ersten moeglichen Platz fuer ein Elektrowerkzeug.
   * @param index Ausgabeparameter fuer den freien Platz. Falls Rueckgabewert
   *   false ist, dann ist dieser Wert ungueltig.
   * @return ob ein gueltiger Index gefunden wurde.
   */
  private boolean checkRoomForPowerTool(Wrapper index) {
    index.set(0);
    boolean room = true;
    while(index.get() <= this.tools.length - Toolbox.PowerToolSize) {
      for(int j = index.get(); j < index.get() + Toolbox.PowerToolSize; ++j) {
        if(this.tools[j] != null) {
          room = false;
          break;
        }
        room = true;
      }
      if(room) {
        return true;
      }
      index.set(index.get()+1);
    }
    return false;
  }

  /**
   * Fuege ein Werkzeug an erster passender Stelle zur Kiste hinzu,
   * falls Platz ist.
   * @param t Das Werkzeug, das hinzugefuegt werden soll.
   */
  public void addTool(Tool t) {
    switch(t) {
      case PowerTool -> {
        Wrapper i = new Wrapper(0);
        if(this.checkRoomForPowerTool(i)) {
          for(int k = 0; k < Toolbox.PowerToolSize; ++k) {
            this.tools[i.get() + k] = t;
          }
        }
      }
      case Materials -> {
        for(int k = 0; k < this.tools.length; ++k) {
          if(this.tools[k] == null) {
            this.tools[k] = t;
            break;
          }
          if(this.tools[k] == Tool.Materials) {
            break;
          }
        }
      }
      case SimpleTool -> {
        for(int k = 0; k < this.tools.length; ++k) {
          if(this.tools[k] == null) {
            this.tools[k] = t;
            break;
          }
        }
      }
    }
  }

  /**
   * Fuege mehrere Werkzeuge an erster passender Stelle zur Kiste hinzu,
   * falls Platz ist.
   * @param tools Werkzeuge, welche hinzugefuegt werden sollen.
   */
  public void addTool(Tool[] tools) {
    for(Tool t: tools)
      addTool(t);
  }
}
