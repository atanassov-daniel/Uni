public enum Tool {
  PowerTool, SimpleTool, Materials
}
