import java.util.Random;

/**
 * Klasse, welche eine Strecke darstellt.
 * Eine Strecke wird hierbei zwischen zwei Punkten aufgespannt.
 */
public class LineSegment {
    /** Zwei Punkte, die eine Strecke definieren. */
    private Point a,b;

    /**
     * Erstellt eine Strecke aus den zwei Endpunkten Point a und Point b.
     * @param a Endpunkt a
     * @param b Endpunkt a
     */
    public LineSegment(Point a, Point b) {
        this.a = a;
        this.b = b;
    }

    /**
     * Erstellt eine Strecke aus den zwei Endpunkten Point (x1,y1) und Point (x2,y2).
     * @param x1 x-Koordinate des 1. Endpunkts
     * @param y1 y-Koordinate des 1. Endpunkts
     * @param x2 x-Koordinate des 2. Endpunkts
     * @param y2 y-Koordinate des 2. Endpunkts
     */
    public LineSegment(int x1, int y1, int x2, int y2) {
        a = new Point(x1,y1);
        b = new Point(x2,y2);
    }

    /**
     * Erstellt eine Strecke zwischen zwei zufaellig gewaehlten Punkten.
     * @param max Die Koordinaten der Punkte liegen zwischen 0 und max - 1.
     */
    public LineSegment(int max) {
        Random rn = new Random();
        a = new Point(rn.nextInt(max),rn.nextInt(max));
        b = new Point(rn.nextInt(max),rn.nextInt(max));
    }

    /**
     * Erstellt eine Strecke zwischen zwei zufaellig gewaehlten Punkten.
     * Hierbei liegen beide Endpunkte length auseinander.
     * @param max Die Koordinaten der Punkte liegen zwischen 0 und max - 1.
     * @param length Abstand zwischen beiden Punkten.
     */
    public LineSegment(int max, int length) {
        Random rn = new Random();

        a = new Point(rn.nextInt(max),rn.nextInt(max));
        Point b;
        do {
            double angle = rn.nextInt(360) * Math.PI / 180;
            double x1 = a.x() + length * Math.cos(angle);
            double y1 = a.y() + length * Math.sin(angle);
            b = new Point((int) x1, (int) y1);
        } while(b.x() < 0 || b.x() >= max || b.y() < 0 || b.y() >= max);
        this.b = b;
    }

    /**
     * Getter-Methode fuer 1. Endpunkt.
     * @return 1. Endpunkt
     */
    public Point getA() {
        return a;
    }

    /**
     * Getter-Methode fuer 2. Endpunkt.
     * @return 2. Endpunkt
     */
    public Point getB() {
        return b;
    }

    /**
     * Setter-Methode fuer 1. Endpunkt
     * @param p Neuer 1. Endpunkt
     */
    public void setA(Point p) {
        this.a = p;
    }

    /**
     * Setter-Methode fuer 2. Endpunkt
     * @param p Neuer 2. Endpunkt
     */
    public void setB(Point p) {
        this.b = p;
    }

    /**
     * Methode, welche fuer eine Strecke einen geeigneten String ausgibt.
     * @return Strecke aus Endpunkten a und b wird als "a -- b" ausgegeben.
     */
    @Override
    public String toString() {
        return a.toString() + " -- " + b.toString();
    }

    /**
     * Methode generiert n horizontale, parallele Strecken mit Abstand distance / (n - 1)
     * @param distance Gesamt Distanz ueber der Strecken erzeugt werden sollen
     * @param n Anzahl der Strecken, die erzeugt werden sollen
     * @return Array von n neu erzeugten Strecken
     */
    public static LineSegment[] spawnParallel(int distance, int n) {
        LineSegment[] lines = new LineSegment[n];
        int distance_two_lines = distance / (n - 1);
        for(int i = 0; i < n; i++)
            lines[i] =
                new LineSegment(0, distance_two_lines * i, distance, distance_two_lines * i);
        return lines;
    }

    /**
     * Methode prueft, ob this mit der uebergebenen horizontalen Gerade l
     * einen Schnittpunkt hat.
     * @param l Horizontale Gerade l
     * @return true gdw. ein Schnittpunkt existiert
     */
    public boolean intersectHorizontal(LineSegment l) {
        boolean under = this.getA().y() < l.getA().y() && this.getB().y() < l.getB().y();
        boolean above = this.getA().y() > l.getA().y() && this.getB().y() > l.getB().y();
        return !(under || above);
    }

    /**
     * Methode prueft, ob diese Strecke mit einer der uebergebenen horizontalen Geraden
     * aus parallel einen Schnittpunkt hat.
     * @param parallel Array von horizontalen Geraden
     * @return true gdw. eine horizontale Gerade mit Schnittpunkt existiert
     */
    public boolean intersectHorizontal(LineSegment[] parallel) {
        for(LineSegment l: parallel) {
            if(this.intersectHorizontal(l))
                return true;
        }
        return false;
    }

    /**
     * Berechnet Verhaeltnis von Schnittpunkten und erzeugten Strecken.
     * Existiert kein Schnittpunkt, so wird 0 zurueckgegeben.
     * @param parallel Array von horizontalen Geraden
     * @param random Zufaellig erzeugte Strecken
     * @return Verhaeltnis von Schnittpunkten und erzeugten Strecken
     */
    static double computeValue(LineSegment[] parallel, LineSegment[] random) {
        int countIntersections = 0;
        for(LineSegment l: random) {
            if(l.intersectHorizontal(parallel))
                countIntersections++;
        }
        if (countIntersections == 0)
            return 0.0;
        return 2.0 * random.length / countIntersections;
    }
}
