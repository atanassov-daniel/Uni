/**
 *  Objekte dieser Klasse repraesentieren Punkte bestehend aus einer x- und y-Koordinate.
 */
public record Point(int x, int y) {
    /**
     * Methode, welche fuer einen Punkt einen geeigneten String ausgibt.
     * @return Punkt wird als "(x,y)" ausgegeben
     */
    @Override
    public String toString() {
        return "(" + x + "," + y + ")";
    }

    /**
     * Berechnet 2-Norm dieses Punktes.
     * @return sqrt(x^2 + y^2)
     */
    public double norm2() {
        return Math.sqrt(x*x + y*y);
    }
}
