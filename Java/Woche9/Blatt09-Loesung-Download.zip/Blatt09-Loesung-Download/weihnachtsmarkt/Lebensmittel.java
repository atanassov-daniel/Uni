public interface Lebensmittel {
	double getPreisPro100g();

	String getName();
}
