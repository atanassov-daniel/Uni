public interface Verschiebbar {
	void verschiebe(int standID) throws SchadensfallException;
}
