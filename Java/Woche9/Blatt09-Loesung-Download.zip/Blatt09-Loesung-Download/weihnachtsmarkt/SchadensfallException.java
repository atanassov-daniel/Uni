public class SchadensfallException extends Exception {
	public SchadensfallException(String message) {
		super(message);
	}
}
