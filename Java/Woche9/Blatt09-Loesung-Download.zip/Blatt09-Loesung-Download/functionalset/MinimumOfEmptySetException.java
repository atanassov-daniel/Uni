public class MinimumOfEmptySetException extends java.lang.RuntimeException{}
