import java.util.HashSet;
import java.util.Set;

public class ArrayMap<K, V> extends AbstractMap<K, V> {
	protected Entry<K, V>[] entries;

	public ArrayMap(Entry<K, V>[] entries) {
		this.entries = GenericArrayHelper.copyArray(entries);
	}

	public ArrayMap() {
		this.entries = GenericArrayHelper.newEntryArrayOfSize(10);
	}

	@Override
	public V getOrThrow(K key) throws UnknownKeyException {
		for (Entry<K, V> entry : entries) {
			if (entry != null && entry.getKey().equals(key)) {
				return entry.getValue();
			}
		}
		throw new UnknownKeyException();
	}

	@Override
	public Set<K> keysAsSet() {
		Set<K> result = new HashSet<K>();
		for (Entry<K, V> entry : entries) {
			if (entry != null) {
				result.add(entry.getKey());
			}
		}
		return result;
	}

	@Override
	public void put(K key, V value) {
		for (int i = 0; i < entries.length; i++) {
			if (entries[i] == null || entries[i].getKey().equals(key)) {
				entries[i] = new Entry<K, V>(key, value);
				return;
			}
		}
		int newIndex = entries.length;
		entries = GenericArrayHelper.copyArrayWithIncreasedSize(entries,
				2 * entries.length);
		entries[newIndex] = new Entry<K, V>(key, value);
	}
}
