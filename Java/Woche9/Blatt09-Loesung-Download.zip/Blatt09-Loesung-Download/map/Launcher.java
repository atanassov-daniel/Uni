import java.util.HashSet;
import java.util.Set;

public class Launcher {
	public static void main(String[] args) {
		ArrayMap<String, Integer> map = new ArrayMap<String, Integer>();
		putEntries(map);
		printMap(map);

		Set<String> set = new HashSet<String>();
		set.add("unknown");
		try {
			map.getValuesAsSetOrThrow(set);
		} catch (UnknownKeyException e) {
			System.out.println("unknown key");
		}
	}

	private static void putEntries(AbstractMap<String, Integer> map) {
		map.put("sizeInMB", 42);
		map.put("version", 4);
		map.put("yearOfRelease", 2015);
	}

	private static <K, V> void printMap(AbstractMap<K, V> map) {
		try {
			for (K key : map.keysAsSet()) {
				System.out.println(key + ": " + map.getOrThrow(key));
			}
		} catch (UnknownKeyException e) {
			// Da wir nur auf keys zugreifen, welche in der map enthalten sind,
			// sollte diese Exception nie auftreten. Sie muss aber trotzdem
			// gefangen und behandelt werden.
			System.out.println("unknown key");
		}
	}
}
