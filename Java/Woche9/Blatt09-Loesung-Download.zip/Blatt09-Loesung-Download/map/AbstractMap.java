import java.util.Set;
import java.util.HashSet;

public abstract class AbstractMap<K, V> {
	public abstract V getOrThrow(K key) throws UnknownKeyException;

	public abstract void put(K key, V value);

	public Set<V> getValuesAsSetOrThrow(Set<K> keys) throws UnknownKeyException {
		Set<V> result = new HashSet<V>();
		for (K key : keys) {
			result.add(getOrThrow(key));
		}
		return result;
	}

	// Aufgabenteil e)
	public abstract Set<K> keysAsSet();
}
