public class UnknownKeyException extends Exception {
}