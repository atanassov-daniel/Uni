enum Farbe {
    KREUZ, PIK, HERZ, KARO;
}