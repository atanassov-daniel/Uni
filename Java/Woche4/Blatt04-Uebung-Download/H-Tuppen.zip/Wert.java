enum Wert {
    /* Die Werte sind in der angegebenen Reihenfolge geordnet, d.h. Bube ist der niedrigste Wert und Zehn der höchste. 
    Jede Kombination aus Wert und Farbe kommt in einem Skatblatt genau einmal vor. Wir
    */
    BUBE, DAME, KOENIG, ASS, SIEBEN, ACHT, NEUN, ZEHN;
}