public class Stadt {
	private Buerger[] buerger;

	public Stadt(int anzahl) {
		this.buerger = new Buerger[anzahl];
		for (int i = 0; i < this.buerger.length; i++) {
			String name = Zufall.name();
			this.buerger[i] = switch (Zufall.zahl(4)) {
				case 0 -> new Dieb(name);
				case 1 -> new ReicherBuerger(name, Zufall.zahl(1000) + 1);
				case 2 -> new Polizist(name);
				default -> new Gefangener(name);
			};
		}
	}

	public static void main(String[] args) {
		Stadt stadt = new Stadt(10);
		for (int i = 0; i < 10; i++) {
			int zufallsIndex = Zufall.zahl(stadt.buerger.length);
			stadt.buerger[zufallsIndex].aktion(stadt.buerger);
		}
	}
}
