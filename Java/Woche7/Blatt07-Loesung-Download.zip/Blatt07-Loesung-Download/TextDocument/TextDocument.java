public class TextDocument {
	private final String content;

	public TextDocument(String content) {
		this.content = content;
	}

	public String getContent() {
		return content;
	}

	public TextDocument undo() {
		return this;
	}

	public TextDocument noop() {
		return new ModifiedTextDocument(content, this);
	}

	public TextDocument replaceTextSection(int beginIndex, int endIndex, String replacement) {
		String newContent = content.substring(0, beginIndex) + replacement + content.substring(endIndex);
		return new ModifiedTextDocument(newContent, this);
	}

	public TextDocument addTextAt(int position, String addition) {
		return replaceTextSection(position, position, addition);
	}

	public TextDocument removeTextSection(int beginIndex, int endIndex) {
		return replaceTextSection(beginIndex, endIndex, "");
	}
}
