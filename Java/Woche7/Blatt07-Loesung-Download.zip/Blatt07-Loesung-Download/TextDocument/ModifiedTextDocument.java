public class ModifiedTextDocument extends TextDocument {
	private final TextDocument previous;

	public ModifiedTextDocument(String content, TextDocument previous) {
		super(content);
		this.previous = previous;
	}

	@Override
	public TextDocument undo() {
		return previous;
	}
}
